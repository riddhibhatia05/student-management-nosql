# Student Attendance & Performance Management System — MongoDB / NoSQL

ADBMS mini-project using React + Node.js + Express + MongoDB.

## Requirements
- Node.js 18+
- MongoDB Community Server OR MongoDB Atlas
- Browser

## Setup

### Backend
Open a terminal in `backend`:
```bash
npm install
```
Copy `.env.example` to `.env`. For local MongoDB:
```env
MONGO_URI=mongodb://127.0.0.1:27017/student_management_nosql
PORT=5000
```
Then:
```bash
npm run seed
npm start
```
Test `http://localhost:5000/api/health`.

### Frontend
Open another terminal in `frontend`:
```bash
npm install
npm run dev
```
Open the Vite URL, normally `http://localhost:5173`.

## NoSQL concepts demonstrated
- MongoDB document-oriented storage
- Flexible/semi-structured BSON documents
- CRUD
- ObjectId references
- Indexes
- Aggregation pipelines
- `$lookup`, `$group`, `$project`
- Mongoose validation

Collections: `students`, `subjects`, `attendances`, `marks`.

**Important:** This is the MongoDB version. MySQL is not required.
