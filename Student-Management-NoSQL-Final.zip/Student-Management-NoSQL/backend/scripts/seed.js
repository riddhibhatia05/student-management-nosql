require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("../db");
const Student = require("../models/Student");
const Subject = require("../models/Subject");
const Attendance = require("../models/Attendance");
const Mark = require("../models/Mark");

async function seed(){
  await connectDB();
  await Promise.all([
    Student.deleteMany({}), Subject.deleteMany({}),
    Attendance.deleteMany({}), Mark.deleteMany({})
  ]);

  const students = await Student.insertMany([
    {name:"Aarav Sharma",email:"aarav@example.com",course:"M.Sc. Computer Science",semester:1,contact:"9876543210",skills:["JavaScript","Python","MongoDB"]},
    {name:"Ananya Mehta",email:"ananya@example.com",course:"M.Sc. Computer Science",semester:1,contact:"9876543211",skills:["Java","SQL","React"]},
    {name:"Kabir Shah",email:"kabir@example.com",course:"M.Sc. Computer Science",semester:1,contact:"9876543212",skills:["C++","Node.js"]},
    {name:"Isha Patel",email:"isha@example.com",course:"M.Sc. Computer Science",semester:1,contact:"9876543213",skills:["Python","Data Analytics"]}
  ]);

  const subjects = await Subject.insertMany([
    {subjectName:"Advanced Database Management Systems",semester:1,faculty:"Dr. Rao"},
    {subjectName:"Software Engineering",semester:1,faculty:"Prof. Kulkarni"},
    {subjectName:"Computer Networks",semester:1,faculty:"Prof. Mehta"}
  ]);

  const dates=["2026-09-01","2026-09-03","2026-09-05","2026-09-08"].map(x=>new Date(x));
  const attendance=[];
  students.forEach((st,i)=>subjects.forEach((sub,j)=>dates.forEach((date,k)=>{
    const absent=(i+j+k)%5===0;
    attendance.push({studentId:st._id,subjectId:sub._id,date,status:absent?"Absent":"Present",remarks:absent?"Leave":""
    });
  })));
  await Attendance.insertMany(attendance);

  const marks=[];
  students.forEach((st,i)=>subjects.forEach((sub,j)=>{
    marks.push({studentId:st._id,subjectId:sub._id,assessmentType:"Internal Assessment",
      internal:25+((i*3+j)%11),external:42+((i*5+j*2)%16),remarks:"Sample assessment record"});
  }));
  await Mark.insertMany(marks);
  console.log("Sample MongoDB data inserted successfully.");
  await mongoose.connection.close();
}
seed().catch(async e=>{console.error(e);await mongoose.connection.close();process.exit(1);});
