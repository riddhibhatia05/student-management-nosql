const express = require("express");
const Attendance = require("../models/Attendance");
const router = express.Router();
router.get("/", async (req,res) => {
  try {
    res.json(await Attendance.find()
      .populate("studentId","name email")
      .populate("subjectId","subjectName")
      .sort({date:-1}));
  } catch(e){ res.status(500).json({message:e.message}); }
});
router.post("/", async (req,res) => {
  try {
    const x = await Attendance.create(req.body);
    await x.populate([{path:"studentId",select:"name email"},{path:"subjectId",select:"subjectName"}]);
    res.status(201).json(x);
  } catch(e){ res.status(400).json({message:e.message}); }
});
module.exports = router;
