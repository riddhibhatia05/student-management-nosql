const express = require("express");
const Student = require("../models/Student");
const router = express.Router();

router.get("/", async (req,res) => {
  try { res.json(await Student.find().sort({createdAt:-1})); }
  catch(e){ res.status(500).json({message:e.message}); }
});
router.post("/", async (req,res) => {
  try { res.status(201).json(await Student.create(req.body)); }
  catch(e){ res.status(400).json({message:e.message}); }
});
router.delete("/:id", async (req,res) => {
  try {
    const x = await Student.findByIdAndDelete(req.params.id);
    if(!x) return res.status(404).json({message:"Student not found"});
    res.json({message:"Student deleted successfully"});
  } catch(e){ res.status(400).json({message:e.message}); }
});
module.exports = router;
