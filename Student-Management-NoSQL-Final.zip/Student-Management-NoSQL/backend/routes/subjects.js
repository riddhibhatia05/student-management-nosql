const express = require("express");
const Subject = require("../models/Subject");
const router = express.Router();
router.get("/", async (req,res) => {
  try { res.json(await Subject.find().sort({semester:1,subjectName:1})); }
  catch(e){ res.status(500).json({message:e.message}); }
});
router.post("/", async (req,res) => {
  try { res.status(201).json(await Subject.create(req.body)); }
  catch(e){ res.status(400).json({message:e.message}); }
});
module.exports = router;
