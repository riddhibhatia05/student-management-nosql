const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
  subjectId: { type: mongoose.Schema.Types.ObjectId, ref: "Subject", required: true },
  date: { type: Date, required: true },
  status: { type: String, enum: ["Present", "Absent"], required: true },
  remarks: { type: String, default: "" }
}, { timestamps: true });
schema.index({ studentId: 1, subjectId: 1, date: 1 });
module.exports = mongoose.model("Attendance", schema);
