const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  course: { type: String, required: true },
  semester: { type: Number, required: true, min: 1, max: 8 },
  contact: String,
  skills: { type: [String], default: [] }
}, { timestamps: true });
schema.index({ email: 1 }, { unique: true });
module.exports = mongoose.model("Student", schema);
