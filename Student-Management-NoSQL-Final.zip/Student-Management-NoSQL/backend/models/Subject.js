const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  subjectName: { type: String, required: true, trim: true },
  semester: { type: Number, required: true, min: 1, max: 8 },
  faculty: { type: String, required: true, trim: true }
}, { timestamps: true });
schema.index({ subjectName: 1, semester: 1 });
module.exports = mongoose.model("Subject", schema);
