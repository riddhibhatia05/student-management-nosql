const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
  subjectId: { type: mongoose.Schema.Types.ObjectId, ref: "Subject", required: true },
  assessmentType: { type: String, required: true },
  internal: { type: Number, min: 0, max: 40, default: 0 },
  external: { type: Number, min: 0, max: 60, default: 0 },
  remarks: { type: String, default: "" }
}, { timestamps: true });
schema.index({ studentId: 1, subjectId: 1 });
module.exports = mongoose.model("Mark", schema);
