// MongoDB / ADBMS Viva Query Sheet
// mongosh:
// use student_management_nosql

show collections

db.students.insertOne({
  name:"Demo Student", email:"demo@example.com",
  course:"M.Sc. Computer Science", semester:1,
  skills:["MongoDB","React"]
})

db.students.find()
db.students.find({semester:1})
db.students.find({skills:"MongoDB"})

db.students.updateOne(
  {email:"demo@example.com"},
  {$set:{contact:"9999999999"}}
)

db.students.deleteOne({email:"demo@example.com"})

db.students.createIndex({email:1},{unique:true})
db.attendances.createIndex({studentId:1,subjectId:1,date:1})

db.attendances.aggregate([
  {$group:{_id:"$status",total:{$sum:1}}}
])

db.attendances.aggregate([
  {$group:{
    _id:"$studentId",
    total:{$sum:1},
    present:{$sum:{$cond:[{$eq:["$status","Present"]},1,0]}}
  }},
  {$project:{
    total:1,present:1,
    percentage:{$multiply:[{$divide:["$present","$total"]},100]}
  }}
])

db.attendances.aggregate([
  {$lookup:{
    from:"students",
    localField:"studentId",
    foreignField:"_id",
    as:"student"
  }}
])

db.students.find({semester:1}).explain("executionStats")
