# ADBMS Mini Project Report

## Title
Student Attendance & Performance Management System using MongoDB

## Abstract
This web-based mini-project demonstrates NoSQL database concepts using MongoDB. Student, subject, attendance and marks information is stored in MongoDB collections. A React frontend communicates with a Node.js/Express backend. MongoDB aggregation is used to calculate attendance and performance summaries.

## Objectives
- Store student data as MongoDB documents.
- Demonstrate CRUD operations.
- Manage attendance and marks.
- Demonstrate indexing.
- Use aggregation pipelines for analysis.
- Provide a simple database-driven web interface.

## NoSQL Justification
MongoDB is a NoSQL, document-oriented database that stores BSON documents and supports flexible/semi-structured schemas. The project therefore demonstrates NoSQL concepts instead of relational SQL tables.

## Collections
- students
- subjects
- attendances
- marks

## Concepts demonstrated
Document storage, collections, CRUD, ObjectId references, indexes, aggregation, `$lookup`, `$group`, `$project`, and Mongoose validation.

## Architecture
React Frontend -> REST API -> Node.js/Express -> Mongoose -> MongoDB

## Viva
**What is MongoDB?** A NoSQL, document-oriented database storing flexible BSON documents.

**What is a collection?** A group of MongoDB documents, broadly comparable to a relational table.

**What is CRUD?** Create, Read, Update and Delete.

**What is aggregation?** MongoDB's framework for processing documents through stages to calculate and transform results.

**Why use `$lookup`?** It provides join-like functionality by matching documents across collections.

**What is an index?** A data structure that helps MongoDB locate matching documents more efficiently.

**Is MongoDB simply an unstructured database?** More accurately, it is a NoSQL document-oriented database with a flexible schema; documents can be semi-structured.
