import {useEffect,useState} from "react";
const API="http://localhost:5000/api";

export default function App(){
  const [dashboard,setDashboard]=useState(null),[students,setStudents]=useState([]),[subjects,setSubjects]=useState([]),[summary,setSummary]=useState([]),[message,setMessage]=useState("");
  const [form,setForm]=useState({name:"",email:"",course:"M.Sc. Computer Science",semester:1,contact:"",skills:""});
  const [af,setAf]=useState({studentId:"",subjectId:"",date:new Date().toISOString().slice(0,10),status:"Present",remarks:""});
  const [mf,setMf]=useState({studentId:"",subjectId:"",assessmentType:"Internal Assessment",internal:30,external:45,remarks:""});

  async function load(){
    try{
      const [d,s,sub,p]=await Promise.all([
        fetch(`${API}/dashboard`).then(r=>r.json()),fetch(`${API}/students`).then(r=>r.json()),
        fetch(`${API}/subjects`).then(r=>r.json()),fetch(`${API}/performance/summary`).then(r=>r.json())
      ]);
      setDashboard(d);setStudents(s);setSubjects(sub);setSummary(p);
    }catch{setMessage("Could not connect. Start MongoDB and the backend first.");}
  }
  useEffect(()=>{load()},[]);

  async function addStudent(e){
    e.preventDefault();
    const r=await fetch(`${API}/students`,{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({...form,semester:Number(form.semester),skills:form.skills.split(",").map(x=>x.trim()).filter(Boolean)})});
    const d=await r.json(); if(!r.ok)return setMessage(d.message||"Unable to add student.");
    setForm({name:"",email:"",course:"M.Sc. Computer Science",semester:1,contact:"",skills:""});
    setMessage("Student added successfully.");load();
  }
  async function del(id){
    if(!confirm("Delete this student?"))return;
    const d=await fetch(`${API}/students/${id}`,{method:"DELETE"}).then(r=>r.json());
    setMessage(d.message);load();
  }
  async function saveAttendance(e){
    e.preventDefault();
    const r=await fetch(`${API}/attendance`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(af)});
    const d=await r.json();if(!r.ok)return setMessage(d.message||"Unable to save attendance.");
    setMessage("Attendance saved.");load();
  }
  async function saveMark(e){
    e.preventDefault();
    const r=await fetch(`${API}/marks`,{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({...mf,internal:Number(mf.internal),external:Number(mf.external)})});
    const d=await r.json();if(!r.ok)return setMessage(d.message||"Unable to save marks.");
    setMessage("Marks saved.");load();
  }
  const set=(setter)=>(e)=>setter(x=>({...x,[e.target.name]:e.target.value}));

  return <div className="app">
    <header className="hero"><div><small>ADBMS • NoSQL Mini Project</small><h1>Student Attendance & Performance</h1><p>React + Node.js + MongoDB</p></div><b className="badge">● MongoDB</b></header>
    {message&&<div className="message">{message}</div>}
    <section className="stats">
      <div><span>Students</span><strong>{dashboard?.students??"—"}</strong></div>
      <div><span>Subjects</span><strong>{dashboard?.subjects??"—"}</strong></div>
      <div><span>Attendance Records</span><strong>{dashboard?.attendanceRecords??"—"}</strong></div>
      <div><span>Avg Attendance</span><strong>{dashboard?dashboard.attendancePercentage+"%":"—"}</strong></div>
    </section>

    <main className="grid">
      <section className="card"><h2>Add Student</h2><form onSubmit={addStudent}>
        <input name="name" required placeholder="Full name" value={form.name} onChange={set(setForm)}/>
        <input name="email" required type="email" placeholder="Email" value={form.email} onChange={set(setForm)}/>
        <input name="course" required placeholder="Course" value={form.course} onChange={set(setForm)}/>
        <input name="semester" required type="number" min="1" max="8" value={form.semester} onChange={set(setForm)}/>
        <input name="contact" placeholder="Contact" value={form.contact} onChange={set(setForm)}/>
        <input name="skills" placeholder="Skills, comma separated" value={form.skills} onChange={set(setForm)}/>
        <button>Add Student</button>
      </form></section>

      <section className="card"><h2>Record Attendance</h2><form onSubmit={saveAttendance}>
        <select required name="studentId" value={af.studentId} onChange={set(setAf)}><option value="">Select student</option>{students.map(s=><option key={s._id} value={s._id}>{s.name}</option>)}</select>
        <select required name="subjectId" value={af.subjectId} onChange={set(setAf)}><option value="">Select subject</option>{subjects.map(s=><option key={s._id} value={s._id}>{s.subjectName}</option>)}</select>
        <input required name="date" type="date" value={af.date} onChange={set(setAf)}/>
        <select name="status" value={af.status} onChange={set(setAf)}><option>Present</option><option>Absent</option></select>
        <input name="remarks" placeholder="Remarks" value={af.remarks} onChange={set(setAf)}/>
        <button>Save Attendance</button>
      </form></section>

      <section className="card"><h2>Record Marks</h2><form onSubmit={saveMark}>
        <select required name="studentId" value={mf.studentId} onChange={set(setMf)}><option value="">Select student</option>{students.map(s=><option key={s._id} value={s._id}>{s.name}</option>)}</select>
        <select required name="subjectId" value={mf.subjectId} onChange={set(setMf)}><option value="">Select subject</option>{subjects.map(s=><option key={s._id} value={s._id}>{s.subjectName}</option>)}</select>
        <input name="assessmentType" value={mf.assessmentType} onChange={set(setMf)} placeholder="Assessment type"/>
        <div className="two"><input name="internal" type="number" min="0" max="40" value={mf.internal} onChange={set(setMf)}/><input name="external" type="number" min="0" max="60" value={mf.external} onChange={set(setMf)}/></div>
        <input name="remarks" placeholder="Remarks" value={mf.remarks} onChange={set(setMf)}/>
        <button>Save Marks</button>
      </form></section>

      <section className="card"><h2>MongoDB Concepts</h2><div className="chips">{["Documents","Collections","CRUD","Indexes","Aggregation","$lookup","$group","ObjectId"].map(x=><span key={x}>{x}</span>)}</div><p>Uses Mongoose validation and a MongoDB aggregation pipeline for the performance summary.</p></section>
    </main>

    <section className="card table"><h2>Students</h2><p>MongoDB <code>students</code> collection</p><div className="wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Course</th><th>Sem.</th><th>Skills</th><th/></tr></thead><tbody>
      {students.map(s=><tr key={s._id}><td>{s.name}</td><td>{s.email}</td><td>{s.course}</td><td>{s.semester}</td><td>{(s.skills||[]).join(", ")||"—"}</td><td><button className="danger" onClick={()=>del(s._id)}>Delete</button></td></tr>)}
    </tbody></table></div></section>

    <section className="card table"><h2>Performance Summary</h2><p>Calculated through a MongoDB aggregation pipeline.</p><div className="wrap"><table><thead><tr><th>Student</th><th>Course</th><th>Attendance</th><th>Average Marks</th></tr></thead><tbody>
      {summary.map(s=><tr key={s._id}><td>{s.name}</td><td>{s.course}</td><td>{s.attendancePercentage}%</td><td>{s.averageMarks}/100</td></tr>)}
    </tbody></table></div></section>
    <footer>Student Attendance & Performance Management System • ADBMS • MongoDB / NoSQL</footer>
  </div>
}
